﻿using CS426.node;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CS426.analysis
{
    class CodeGenerator : DepthFirstAdapter
    {
        private StreamWriter _output;

        public CodeGenerator()
        {
            _output = new StreamWriter("program.il");
        }

        private void Write(String textToWrite)
        {
            Console.Write(textToWrite);
            _output.Write(textToWrite);
        }

        private void WriteLine(String textToWrite)
        {
            Console.WriteLine(textToWrite);
            _output.WriteLine(textToWrite);
        }

        public override void InAProgram(AProgram node)
        {
            WriteLine(".assembly extern mscorlib {}");
            WriteLine(".assembly toyprogram");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAProgram(AProgram node)
        {
            _output.Close();
        }

        public override void InAMainfunction(AMainfunction node)
        {
            WriteLine(".method static void main() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            WriteLine("\t.entrypoint\n");
        }

        public override void OutAMainfunction(AMainfunction node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        public override void OutADeclareStatement(ADeclareStatement node)
        {
            WriteLine("\t// Declaring Variable " + node.GetVarname().Text);

            Write("\t.locals init (");

            // TODO Declare the Variable Here
            if (node.GetType().Text == "int")
            {
                Write("int32 ");
            }
            else
            {
                Write(node.GetType().Text + " ");
            }

            Write(node.GetVarname().Text);

            WriteLine(")\n");
        }



    }
}