﻿using CS426.node;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CS426.analysis
{
    class CodeGenerator : DepthFirstAdapter
    {
        private StreamWriter _output;
        private int counter = 0;

        public CodeGenerator()
        {
            _output = new StreamWriter("program2.il");
        }

        private void Write(String textToWrite)
        {
            Console.Write(textToWrite);
            _output.Write(textToWrite);
        }

        private void WriteLine(String textToWrite)
        {
            Console.WriteLine(textToWrite);
            _output.WriteLine(textToWrite);
        }

        public override void InAPassProgram(APassProgram node)
        {
            WriteLine(".assembly extern mscorlib {}");
            WriteLine(".assembly toyprogram");
            WriteLine("{\n\t.ver 1:0:1:0\n}\n");
        }

        public override void OutAPassProgram(APassProgram node)
        {
            _output.Close();
        }

        public override void InAMainMainProgram(AMainMainProgram node)
        {
            WriteLine(".method static void main() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128");
            WriteLine("\t.entrypoint\n");
        }

        public override void OutAMainMainProgram(AMainMainProgram node)
        {
            WriteLine("\n\tret");
            WriteLine("}");
        }

        public override void OutADeclarationDeclareStatement(ADeclarationDeclareStatement node)
        {
            WriteLine("\t// Declaring Variable " + node.GetVarname().Text);

            Write("\t.locals init (");

            // TODO Declare the Variable Here
            if (node.GetType().Text == "int")
            {
                Write("int32 ");
            }
            else if (node.GetType().Text == "float")
            {
                Write("float32 ");
            }
            else if (node.GetType().Text == "string")
            {
                Write("string ");
            }
            else
            {
                Write(node.GetType().Text + " ");
            }

            Write(node.GetVarname().Text);

            WriteLine(")");

        }

        public override void OutAIntOperand(AIntOperand node)
        {
            WriteLine("\tldc.i4 " + node.GetInteger().Text);
        }

        public override void OutAStringOperand(AStringOperand node)
        {
            WriteLine("\tldstr " + node.GetString().Text);
        }

        public override void OutAFloatOperand(AFloatOperand node)
        {
            WriteLine("\tldc.r8 " + node.GetFloat().Text);
        }

        public override void OutAVariableOperand(AVariableOperand node)
        {
            WriteLine("\tldloc " + node.GetId().Text);
        }

        public override void OutAAssignmentAssignStatement(AAssignmentAssignStatement node)
        {
            WriteLine("\tstloc " + node.GetId().Text + "\n");
        }

        public override void OutAAddExpression2(AAddExpression2 node)
        {
            WriteLine("\tadd");
        }
        public override void OutAMinusExpression2(AMinusExpression2 node)
        {
            WriteLine("\tsub");
        }

        public override void OutADivExpression(ADivExpression node)
        {
            WriteLine("\tdiv");
        }

        public override void OutAMultExpression(AMultExpression node)
        {
            WriteLine("\tmul");
        }

        public override void OutANegExpression3(ANegExpression3 node)
        {
            WriteLine("\tneg");
        }

        public override void OutACallFunctionCallStatement(ACallFunctionCallStatement node)
        {
            if (node.GetId().Text == "printInt")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(int32)");
            }
            else if (node.GetId().Text == "printFloat")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(float32)");
            }
            else if (node.GetId().Text == "printString")
            {
                WriteLine("\tcall void [mscorlib]System.Console::Write(string)");
            }
            else
            {
                WriteLine("\tcall void " + node.GetId().Text + "()");
            }

            WriteLine("");
        }

        public override void InASingleFunctionDec(ASingleFunctionDec node)
        {
            WriteLine(".method static void " + node.GetId().Text + "() cil managed");
            WriteLine("{");
            WriteLine("\t.maxstack 128\n");
        }

        public override void OutASingleFunctionDec(ASingleFunctionDec node)
        {
            WriteLine("\tret");
            WriteLine("}\n");
        }

        public override void OutANotExpression3(ANotExpression3 node)
        {
            WriteLine("\tceq");
        }

        public override void OutAAndAndExpression(AAndAndExpression node)
        {
            WriteLine("\tand");
        }

        public override void OutAOrOrExpression(AOrOrExpression node)
        {
            WriteLine("\tor");
        }

        public override void OutAEquivEqualExpressions(AEquivEqualExpressions node)
        {
            Write("\tbeq");
        }

        public override void OutANotEquivEqualExpressions(ANotEquivEqualExpressions node)
        {
            Write("\tbne.un");
        }

        public override void OutALessQuantityExpression(ALessQuantityExpression node)
        {
            Write("\tblt");
        }

        public override void OutALessEqualEqualExpressions(ALessEqualEqualExpressions node)
        {
            Write("\tble");
        }

        public override void OutAGreaterQuantityExpression(AGreaterQuantityExpression node)
        {
            Write("\tbgt");
        }

        public override void OutAGreatEqualEqualExpressions(AGreatEqualEqualExpressions node)
        {
            Write("\tbge");
        }

        public override void OutAConditionalStatement(AConditionalStatement node)
        {
            // Write("\tbrtrue");
        }

        public override void CaseAConditionalIfStatement(AConditionalIfStatement node)
        {
            InAConditionalIfStatement(node);

            if (node.GetKeywordIf() != null)
            {
                node.GetKeywordIf().Apply(this);
            }
            if (node.GetOpenParent() != null)
            {
                node.GetOpenParent().Apply(this);
            }
            if (node.GetOrExpression() != null)
            {
                node.GetOrExpression().Apply(this);
            }

            // We are going compare whatever is on the stack to a 1
            WriteLine(" LABEL_TRUE");
            WriteLine("\t\tldc.i4 0");
            WriteLine("\t\tbr LABEL_CONTINUE:");
            WriteLine("\tLABEL_TRUE:");
            WriteLine("\t\tldc.i4 1");
            WriteLine("\tLABEL_CONTINUE:");
            WriteLine("\tcall void [mscorlib]System.Console::Write(int32)");

            if (node.GetCloseParent() != null)
            {
                node.GetCloseParent().Apply(this);
            }
            if (node.GetLeftBracket() != null)
            {
                node.GetLeftBracket().Apply(this);
            }

            // This is where we do the if statment
            // Note:  Toy Language does not support else
            //        and it will not work for more than
            //        a single IF throughout the program
            /*WriteLine("\n\t// IF TRUE CODE GOES HERE");
            WriteLine("\tbrtrue LABEL_1");
            WriteLine("\tbr LABEL_2");
            WriteLine("\tLABEL_1:");
            */

            if (node.GetStatements() != null)
            {
                node.GetStatements().Apply(this);
            }
            if (node.GetRightBracket() != null)
            {
                node.GetRightBracket().Apply(this);
            }
            if (node.GetElseStatement() != null)
            {
                node.GetElseStatement().Apply(this);
            }



            // WriteLine("\tLABEL_2:");

            OutAConditionalIfStatement(node);
        }

        //public override void CaseAConditionalStatement(AConditionalStatement node)
        //{
        //    InAConditionalStatement(node);

        //    if (node.GetIfStatement() != null)
        //    {
        //        node.GetIfStatement().Apply(this);
        //    }

        //    // We are going compare whatever is on the stack to a 1
        //    WriteLine(" LABEL_TRUE");
        //    WriteLine("\t\tldc.i4 0");
        //    WriteLine("\t\tbr LABEL_CONTINUE:");
        //    WriteLine("\tLABEL_TRUE:");
        //    WriteLine("\t\tldc.i4 1");
        //    WriteLine("\tLABEL_CONTINUE:");

        //    if (node.GetLeftBracket() != null)
        //    {
        //        node.GetLeftBracket().Apply(this);
        //    }

        //    if (node.GetIfStatement.Ge)

        //    // This is where we do the if statment
        //    // Note:  Toy Language does not support else
        //    //        and it will not work for more than
        //    //        a single IF throughout the program
        //    /*WriteLine("\n\t// IF TRUE CODE GOES HERE");
        //    WriteLine("\tbrtrue LABEL_1");
        //    WriteLine("\tbr LABEL_2");
        //    WriteLine("\tLABEL_1:");
        //    */

        //    if (node.GetStatements() != null)
        //    {
        //        node.GetStatements().Apply(this);
        //    }
        //    if (node.GetRightBracket() != null)
        //    {
        //        node.GetRightBracket().Apply(this);
        //    }

        //    // WriteLine("\tLABEL_2:");

        //    OutAMultElseStatement(node);
        //}

        public override void CaseAMultElseStatement(AMultElseStatement node)
        {
            InAMultElseStatement(node);

            if (node.GetKeywordElse() != null)
            {
                node.GetKeywordElse().Apply(this);
            }

            // We are going compare whatever is on the stack to a 1
            WriteLine("\n\tbrtrue LABEL_" + (counter+1));
            WriteLine("\tbr LABEL_" + (counter+2));
            WriteLine("\tLABEL_" + (counter+1) + ":");
            WriteLine("\t  br LABEL_" + (counter+3));
            WriteLine("\tLABEL_" + (counter+2) + ":");
            WriteLine("\tLABEL_" + (counter+3) + ":");

            if (node.GetLeftBracket() != null)
            {
                node.GetLeftBracket().Apply(this);
            }

            // This is where we do the if statment
            // Note:  Toy Language does not support else
            //        and it will not work for more than
            //        a single IF throughout the program
            /*WriteLine("\n\t// IF TRUE CODE GOES HERE");
            WriteLine("\tbrtrue LABEL_1");
            WriteLine("\tbr LABEL_2");
            WriteLine("\tLABEL_1:");
            */

            if (node.GetStatements() != null)
            {
                node.GetStatements().Apply(this);
            }
            if (node.GetRightBracket() != null)
            {
                node.GetRightBracket().Apply(this);
            }


            // WriteLine("\tLABEL_2:");

            OutAMultElseStatement(node);
        }

        public override void CaseALoopWhileStatement(ALoopWhileStatement node)
        {
            InALoopWhileStatement(node);


            //write start loop here

            if (node.GetKeywordWhile() != null)
            {
                node.GetKeywordWhile().Apply(this);
            }
            if (node.GetLeftBracket() != null)
            {
                node.GetLeftBracket().Apply(this);
            }
            if (node.GetOrExpression() != null)
            {
                node.GetOrExpression().Apply(this);
            }
            
            
            
            //perform log here

            //ldcon.id 1
            //beq LABEL_TRUEw while_counter
            //br LABEL_FALSE


            //LABEL_TRUEw:

            if (node.GetRightBracket() != null)
            {
                node.GetRightBracket().Apply(this);
            }
            if (node.GetFirst() != null)
            {
                node.GetFirst().Apply(this);
            }
            if (node.GetStatements() != null)
            {
                node.GetStatements().Apply(this);
            }
            if (node.GetLast() != null)
            {
                node.GetLast().Apply(this);
            }

            //br LABEL_START

            counter++;
            WriteLine("\n\tLABEL_" + counter + ":");
            WriteLine("\tbrzero LABEL_" + (counter + 1));
            WriteLine("\tbr LABEL_" + counter );
            WriteLine("\tLABEL_" + (counter + 1) + ":");
        }
    }
}

